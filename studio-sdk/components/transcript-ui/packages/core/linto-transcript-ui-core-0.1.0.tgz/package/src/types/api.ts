/** Types mirroring the backend API JSON format */

export interface ApiWord {
  /** Legacy identity — still present in Mongo/REST payloads for other
   *  consumers, ignored by the editor (words align by token index). */
  wid?: string
  stime?: number
  etime?: number
  word: string
  confidence?: number
}

export interface ApiTurn {
  speaker_id: string
  turn_id: string
  segment: string
  raw_segment: string
  words: ApiWord[]
  stime?: number
  etime?: number
  language: string
}

export interface ApiSpeaker {
  speaker_id: string
  speaker_name: string
  stime: number
  etime: number
}

export interface ApiAudioMetadata {
  filename: string
  duration: number
  mimetype: string
  filepath: string
}

export interface ApiMetadata {
  transcription: {
    lang: string
    confidence: number
  }
  audio: ApiAudioMetadata
}

export interface ApiDocument {
  name: string
  description: string
  speakers: ApiSpeaker[]
  text: ApiTurn[]
  metadata: ApiMetadata
}
