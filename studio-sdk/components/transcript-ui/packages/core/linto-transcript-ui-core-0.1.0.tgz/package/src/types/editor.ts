/** Internal editor types — backend-agnostic */

export interface Word {
  /** Derived, positional: `${turnId}#${index}`. Recomputed on every text
   *  change — an opaque key for consumers, never persisted. */
  id: string
  text: string
  /** Offsets into the turn's plain text (UTF-16 code units), derived locally
   *  by tokenization — the karaoke/click/follow anchor. */
  charStart?: number
  charEnd?: number
  startTime?: number
  endTime?: number
  confidence?: number
}

export interface Turn {
  id: string
  speakerId: string | null
  text: string | null // non-null when words is empty (live text-only), null otherwise
  words: Word[] // non-empty for word-level detail (ASR), empty when text is the source
  startTime?: number
  endTime?: number
  startDate?: number // Unix timestamp in seconds — wall-clock fallback when startTime is absent
  endDate?: number
  language: string
  /** Original language of the turn (the side being translated from); live-only. */
  sourceLanguage?: string
}

export interface Speaker {
  id: string
  name: string
  color: string
}

export interface AudioSource {
  src: string
  filename?: string
}

export interface Translation {
  id: string
  languages: string[] // ["fr", "en"] for source, ["es"] for auto-translation
  isSource: boolean
  audio?: AudioSource
  turns: Turn[]
}

export interface Channel {
  id: string
  name: string
  description?: string
  duration: number
  translations: Translation[] // at least 1 (the source)
}

export interface EditorDocument {
  title: string
  description?: string
  /** ISO date string or Unix timestamp (seconds) — date the recording took place */
  date?: string | number
  speakers: Map<string, Speaker>
  channels: Channel[]
}
