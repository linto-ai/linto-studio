<script setup lang="ts">
import { Button, CopyButton } from "@linto/transcript-ui-ui"
import { useTurnSelection } from "../composables/useTurnSelection"
import { useI18n } from "@linto/transcript-ui-i18n"

const selection = useTurnSelection()
const { t } = useI18n()
</script>

<template>
  <div
    v-if="selection.hasSelection.value"
    class="selection-bar"
    role="toolbar"
    :aria-label="t('selection.count')">
    <span class="selection-count">
      {{ selection.count.value }} {{ t("selection.count") }}
    </span>
    <div class="selection-actions">
      <CopyButton
        icon="clipboard-type"
        :copy-fn="selection.copyText"
        variant="secondary">
        {{ t("selection.copyText") }}
      </CopyButton>
      <CopyButton icon="clipboard-list" :copy-fn="selection.copyWithMetadata">
        {{ t("selection.copyWithMetadata") }}
      </CopyButton>
      <Button variant="transparent" icon="x" @click="selection.clear()">
        {{ t("selection.cancel") }}
      </Button>
    </div>
  </div>
</template>

<style scoped>
.selection-bar {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--spacing-xs) var(--spacing-lg);
  /* No backdrop-filter: it forces a WebRender backdrop render target sized to
     the content behind, a heavy GPU-memory cost on long transcripts. The
     semi-opaque glass background stays legible without the blur. */
  background: var(--glass-background);
  border-bottom: 1px solid var(--color-border);
  animation: bar-slide-down var(--transition-duration) ease;
}

.selection-count {
  font-size: var(--font-size-sm);
  font-weight: 600;
  color: var(--color-primary);
}

.selection-actions {
  display: flex;
  gap: var(--spacing-xs);
}

@keyframes bar-slide-down {
  from {
    opacity: 0;
    translate: 0 -4px;
  }
  to {
    opacity: 1;
    translate: 0 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .selection-bar {
    animation: none;
  }
}

@media (max-width: 767px) {
  .selection-bar {
    padding: var(--spacing-xs) var(--spacing-md);
    flex-wrap: wrap;
    gap: var(--spacing-xs);
  }
}
</style>
